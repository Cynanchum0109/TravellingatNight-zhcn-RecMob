@echo off
setlocal
title Travelling at Night - Chinese Patch Installer
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer_files\launcher.ps1" -Action install
set "patch_exit=%errorlevel%"
echo.
if "%patch_exit%"=="0" (
  echo Installation completed. You can now start the game from Steam.
) else (
  echo Installation failed. Please check install_result.log.
)
echo.
pause
exit /b %patch_exit%
