@echo off
setlocal
title Travelling at Night - Chinese Patch Uninstaller
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer_files\launcher.ps1" -Action uninstall
set "patch_exit=%errorlevel%"
echo.
if "%patch_exit%"=="0" (
  echo Uninstallation completed.
) else (
  echo Uninstallation failed. Please check install_result.log.
)
echo.
pause
exit /b %patch_exit%
