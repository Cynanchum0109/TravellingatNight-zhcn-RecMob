﻿[CmdletBinding()]
param([ValidateSet("install", "uninstall")][string]$Action,
      [string]$GameDir = "")

$ErrorActionPreference = "Stop"
$PackageRoot = Split-Path -Parent $PSScriptRoot
$LogPath = Join-Path $PackageRoot "install_result.log"
$ScriptPath = Join-Path $PSScriptRoot $(if ($Action -eq "install") { "installer.ps1" } else { "uninstaller.ps1" })
$StateFolderName = ".travellingzh_patch"
$ExitCode = 1
$TranscriptStarted = $false

function Show-Result([string]$Title, [string]$Message, [int]$Icon) {
    try {
        $shell = New-Object -ComObject WScript.Shell
        [void]$shell.Popup($Message, 0, $Title, $Icon)
    } catch {
        Write-Host $Message
    }
}

try {
    Start-Transcript -LiteralPath $LogPath -Force | Out-Null
    $TranscriptStarted = $true
    # The Gitee-side freshen (freshen_payload.ps1) is kept in the repo but
    # not shipped or called: updates go through the COS updater instead.
    # The updater runs the installer out of a temp folder and names the game
    # directory itself; the .cmd launchers leave it to the installer to find.
    if ($GameDir) { & $ScriptPath -GameDir $GameDir } else { & $ScriptPath }
    $ExitCode = 0
    if ($Action -eq "install") {
        $statePath = Join-Path (Split-Path -Parent $PackageRoot) "$StateFolderName\install_manifest.json"
        $detail = ""
        if (Test-Path -LiteralPath $statePath -PathType Leaf) {
            $state = [IO.File]::ReadAllText($statePath, [Text.Encoding]::UTF8) | ConvertFrom-Json
            $detail = "`n汉化版本：$($state.package_version)`n游戏版本：$($state.game_version)"
        }
        Show-Result "汉化：安装完成" ("汉化已经安装完成。" + $detail + "`n`n现在可以从 Steam 启动游戏。") 64
    } else {
        Show-Result "汉化：卸载完成" "汉化已经卸载，原游戏文件已恢复。" 64
    }
} catch {
    $message = $_.Exception.Message
    Write-Host "操作失败：$message" -ForegroundColor Red
    Show-Result "汉化：操作失败" ("操作没有完成：`n$message`n`n详细记录：$LogPath") 16
} finally {
    if ($TranscriptStarted) { Stop-Transcript | Out-Null }
}

exit $ExitCode
