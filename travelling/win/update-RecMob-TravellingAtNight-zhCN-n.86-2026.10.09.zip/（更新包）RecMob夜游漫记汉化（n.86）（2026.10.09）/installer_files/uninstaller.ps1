﻿[CmdletBinding()]
param([string]$GameDir = "")

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$StateFolderName = ".travellingzh_patch"
$PackageRoot = Split-Path -Parent $PSScriptRoot

function Get-FullPath([string]$Path) { return [IO.Path]::GetFullPath($Path).TrimEnd('\') }

function Resolve-SafeTarget([string]$Root, [string]$RelativePath) {
    if ([string]::IsNullOrWhiteSpace($RelativePath)) { throw "安装记录里有空路径。" }
    if ([IO.Path]::IsPathRooted($RelativePath) -or $RelativePath -match '(^|[\\/])\.\.([\\/]|$)') { throw "不安全路径：$RelativePath" }
    $rootFull = (Get-FullPath $Root) + '\'
    $target = [IO.Path]::GetFullPath((Join-Path $Root ($RelativePath -replace '/', '\')))
    if (-not $target.StartsWith($rootFull, [StringComparison]::OrdinalIgnoreCase)) { throw "路径超出游戏目录：$RelativePath" }
    return $target
}

function Get-Sha256([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace("-", "")
    } finally {
        $sha.Dispose()
        $stream.Dispose()
    }
}

function Get-Prop($Object, [string]$Name) {
    if ($null -eq $Object) { return $null }
    $p = $Object.PSObject.Properties[$Name]
    if ($null -eq $p) { return $null }
    return $p.Value
}

# Same Steam lookup the installer uses: the patch folder may have been moved
# out of the game directory since installing, and the uninstaller still needs
# to find the files it laid down.
function Get-SteamLibraries {
    $libraries = @()
    foreach ($key in @("HKCU:\Software\Valve\Steam",
                       "HKLM:\SOFTWARE\WOW6432Node\Valve\Steam",
                       "HKLM:\SOFTWARE\Valve\Steam")) {
        try {
            $steamPath = (Get-ItemProperty -LiteralPath $key -ErrorAction Stop).SteamPath
        } catch { continue }
        if ([string]::IsNullOrWhiteSpace($steamPath)) { continue }
        $steamPath = $steamPath -replace '/', '\'
        if ($libraries -notcontains $steamPath) { $libraries += $steamPath }

        $vdf = Join-Path $steamPath "steamapps\libraryfolders.vdf"
        if (-not (Test-Path -LiteralPath $vdf -PathType Leaf)) { continue }
        try { $text = Get-Content -LiteralPath $vdf -Raw -ErrorAction Stop } catch { continue }
        foreach ($m in [regex]::Matches($text, '"path"\s*"([^"]+)"')) {
            $lib = $m.Groups[1].Value -replace '\\\\', '\'
            if ($libraries -notcontains $lib) { $libraries += $lib }
        }
    }
    return $libraries
}

function Find-SteamGameRoot {
    foreach ($library in Get-SteamLibraries) {
        $common = Join-Path $library "steamapps\common"
        if (-not (Test-Path -LiteralPath $common -PathType Container)) { continue }
        $direct = Join-Path $common "Travelling at Night Demo"
        if (Test-Path -LiteralPath (Join-Path $direct "travelling.exe") -PathType Leaf) {
            return Get-FullPath $direct
        }
        try { $folders = Get-ChildItem -LiteralPath $common -Directory -ErrorAction Stop } catch { continue }
        foreach ($folder in $folders) {
            if (Test-Path -LiteralPath (Join-Path $folder.FullName "travelling.exe") -PathType Leaf) {
                return Get-FullPath $folder.FullName
            }
        }
    }
    return $null
}

function Find-GameRoot([string]$Requested) {
    if (-not [string]::IsNullOrWhiteSpace($Requested)) { return Get-FullPath $Requested.Trim('"') }
    if (Test-Path -LiteralPath (Join-Path $PackageRoot "travelling.exe") -PathType Leaf) { return Get-FullPath $PackageRoot }
    $parent = Split-Path -Parent $PackageRoot
    if (Test-Path -LiteralPath (Join-Path $parent "travelling.exe") -PathType Leaf) { return Get-FullPath $parent }
    $viaSteam = Find-SteamGameRoot
    if ($viaSteam) {
        Write-Host "已通过 Steam 自动定位到游戏目录。"
        return $viaSteam
    }
    throw "没有找到游戏目录。请把汉化包文件夹放回游戏目录后再卸载。"
}

$GameRoot = Find-GameRoot $GameDir
if (Get-Process -Name "travelling" -ErrorAction SilentlyContinue) { throw "游戏正在运行。请完全退出后重试。" }
$StateRoot = Join-Path $GameRoot $StateFolderName
$StateManifestPath = Join-Path $StateRoot "install_manifest.json"
$BackupRoot = Join-Path $StateRoot "backup"
if (-not (Test-Path -LiteralPath $StateManifestPath -PathType Leaf)) { throw "没有找到本组汉化的安装记录。" }
$state = [IO.File]::ReadAllText($StateManifestPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
$preserved = 0
$touchedDirs = New-Object System.Collections.Generic.HashSet[string]

$records = @($state.files)
[array]::Reverse($records)
foreach ($record in $records) {
    $relative = [string]$record.path
    $target = Resolve-SafeTarget $GameRoot $relative
    [void]$touchedDirs.Add((Split-Path -Parent $target))
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { continue }

    # A config the runtime rewrites will never match the shipped hash, so the
    # hash guard is only meaningful for files nothing but the player touches.
    $volatile = [bool](Get-Prop $record "volatile")
    if (-not $volatile -and (Get-Sha256 $target) -ne ([string]$record.sha256).ToUpperInvariant()) {
        Write-Host "保留已被修改的文件：$relative" -ForegroundColor Yellow
        $preserved++
        continue
    }

    switch ([string]$record.disposition) {
        "created" { Remove-Item -LiteralPath $target -Force }
        "replaced" {
            $backupRelative = Get-Prop $record "backup_path"
            if ([string]::IsNullOrEmpty($backupRelative)) { throw "安装记录缺少备份路径：$relative" }
            $backup = Resolve-SafeTarget $BackupRoot ([string]$backupRelative)
            if (-not (Test-Path -LiteralPath $backup -PathType Leaf)) { throw "缺少原文件备份：$relative" }
            Copy-Item -LiteralPath $backup -Destination $target -Force
        }
        "preexisting_identical" { }
        default { throw "未知卸载记录类型：$($record.disposition)" }
    }
}

# Remove the folders the patch introduced, but only while they are empty, so a
# player who also runs other BepInEx mods keeps their plugins.
$gameFull = (Get-FullPath $GameRoot) + '\'
foreach ($dir in ($touchedDirs | Sort-Object -Property Length -Descending)) {
    $current = $dir
    while ($true) {
        if ([string]::IsNullOrEmpty($current)) { break }
        $currentFull = Get-FullPath $current
        if (-not $currentFull.StartsWith($gameFull, [StringComparison]::OrdinalIgnoreCase)) { break }
        if ($currentFull.StartsWith((Get-FullPath $StateRoot), [StringComparison]::OrdinalIgnoreCase)) { break }
        if (-not (Test-Path -LiteralPath $currentFull -PathType Container)) { break }
        if (@(Get-ChildItem -LiteralPath $currentFull -Force).Count -gt 0) { break }
        Remove-Item -LiteralPath $currentFull -Force
        $current = Split-Path -Parent $currentFull
    }
}

if ($preserved -eq 0) {
    $stateFull = Get-FullPath $StateRoot
    if (-not $stateFull.StartsWith($gameFull, [StringComparison]::OrdinalIgnoreCase)) { throw "状态目录安全检查失败。" }
    Remove-Item -LiteralPath $StateRoot -Recurse -Force
    Write-Host "汉化已卸载，安装时覆盖的原文件已恢复。" -ForegroundColor Green
} else {
    Write-Host "卸载完成，但有 $preserved 个用户修改文件被保留；安装记录也暂时保留。" -ForegroundColor Yellow
    Write-Host "确认不再需要后，可手动删除：$StateRoot"
}
