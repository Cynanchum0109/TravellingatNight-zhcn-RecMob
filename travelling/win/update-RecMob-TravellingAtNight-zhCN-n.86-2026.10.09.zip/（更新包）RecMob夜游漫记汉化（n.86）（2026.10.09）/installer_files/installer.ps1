﻿[CmdletBinding()]
param([string]$GameDir = "")

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

# These four are rewritten by scripts/package_release.py when the zip is built,
# so the script and the manifest it validates can never come from different
# builds of the patch.
$PackageName    = "夜游漫记 Demo 简体中文补丁"
$PackageVersion = "v2026.10.09"
$BuiltForGame   = "2026.9.n.86"
$StateFolderName = ".travellingzh_patch"

$PackageRoot = Split-Path -Parent $PSScriptRoot
$PayloadRoot = Join-Path $PSScriptRoot "payload"
$PayloadManifestPath = Join-Path $PSScriptRoot "payload_manifest.json"

function Write-Stage([string]$Message) {
    Write-Host "`n== $Message ==" -ForegroundColor Cyan
}

function Get-FullPath([string]$Path) {
    return [System.IO.Path]::GetFullPath($Path).TrimEnd('\')
}

# Every path that comes out of a manifest is joined through this, so a crafted
# or corrupted manifest cannot write outside the folder it is scoped to.
function Resolve-SafeTarget([string]$Root, [string]$RelativePath) {
    if ([string]::IsNullOrWhiteSpace($RelativePath)) { throw "清单里有空路径。" }
    if ([System.IO.Path]::IsPathRooted($RelativePath) -or $RelativePath -match '(^|[\\/])\.\.([\\/]|$)') {
        throw "清单含不安全路径：$RelativePath"
    }
    $rootFull = (Get-FullPath $Root) + '\'
    $target = [System.IO.Path]::GetFullPath((Join-Path $Root ($RelativePath -replace '/', '\')))
    if (-not $target.StartsWith($rootFull, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "目标超出限定目录：$RelativePath"
    }
    return $target
}

function Get-Sha256([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($sha.ComputeHash($stream))).Replace("-", "")
    } finally {
        $sha.Dispose()
        $stream.Dispose()
    }
}

function Get-Prop($Object, [string]$Name) {
    # Set-StrictMode makes a missing property a terminating error, so every
    # optional manifest field is read through here.
    if ($null -eq $Object) { return $null }
    $p = $Object.PSObject.Properties[$Name]
    if ($null -eq $p) { return $null }
    return $p.Value
}

function Test-TypeCheck($Module, $Check) {
    $typeName = [string]$Check.type
    $type = $Module.Types | Where-Object { $_.FullName -eq $typeName } | Select-Object -First 1
    if ($null -eq $type) { return "缺少类型 $typeName" }

    $methodName = Get-Prop $Check "method"
    if ([string]::IsNullOrEmpty($methodName)) { return $null }

    $candidates = @($type.Methods | Where-Object { $_.Name -eq $methodName })
    if ($candidates.Count -eq 0) { return "缺少方法 $typeName.$methodName" }

    $exact = Get-Prop $Check "parameters"
    if ($null -ne $exact) {
        $expected = @($exact | ForEach-Object { [string]$_ })
        foreach ($m in $candidates) {
            $actual = @($m.Parameters | ForEach-Object { $_.ParameterType.FullName })
            if ($actual.Count -ne $expected.Count) { continue }
            $same = $true
            for ($i = 0; $i -lt $actual.Count; $i++) {
                if ($actual[$i] -ne $expected[$i]) { $same = $false; break }
            }
            if ($same) { return $null }
        }
        return "方法签名已变化：$typeName.$methodName($($expected -join ', '))"
    }

    # The link plugin patches every overload whose first parameter is a string,
    # so what matters is that at least one such overload still exists - not the
    # exact set of overloads, which the game adds to between releases.
    $firstParam = Get-Prop $Check "any_overload_first_parameter"
    if (-not [string]::IsNullOrEmpty($firstParam)) {
        $wantStatic = Get-Prop $Check "static"
        foreach ($m in $candidates) {
            if ($m.Parameters.Count -eq 0) { continue }
            if ($m.Parameters[0].ParameterType.FullName -ne $firstParam) { continue }
            if ($null -ne $wantStatic -and $m.IsStatic -ne [bool]$wantStatic) { continue }
            return $null
        }
        return "没有首参为 $firstParam 的 $typeName.$methodName 重载"
    }

    return $null
}

function Test-GameCompatibility([string]$GameRoot, $Checks) {
    # Returns $true (checked, passed), or $false (could not run the interface
    # check itself - e.g. Cecil won't load on this PowerShell runtime). A real
    # interface mismatch always throws; only "we couldn't check" degrades.
    if ($null -eq $Checks -or @($Checks).Count -eq 0) {
        throw "安装清单没有兼容性检测项，拒绝安装。"
    }
    $managed = Join-Path $GameRoot "travelling_Data\Managed"
    if (-not (Test-Path -LiteralPath $managed -PathType Container)) {
        throw "游戏目录结构异常：找不到 travelling_Data\Managed。"
    }
    # An update package ships no BepInEx/core - it assumes a full package put
    # one there already - so fall back to the installed copy. Safe by then:
    # the update gate above has confirmed a hash-verified install exists.
    $cecilPath = Join-Path $PayloadRoot "BepInEx\core\Mono.Cecil.dll"
    if (-not (Test-Path -LiteralPath $cecilPath -PathType Leaf)) {
        $cecilPath = Join-Path $GameRoot "BepInEx\core\Mono.Cecil.dll"
    }
    if (-not (Test-Path -LiteralPath $cecilPath -PathType Leaf)) { throw "安装包缺少兼容性检测组件。" }
    # Loaded from bytes, not by path: a zip fetched from the web and unpacked
    # by Explorer leaves a Zone.Identifier mark on every file, and LoadFrom
    # refuses marked assemblies outright (0x80131515). That was every real
    # player - the interface check silently fell back to the version-string
    # compare for all of them, and nobody saw it until a k.97 package met a
    # m.94 game (2026-09-16). Byte loading has no such check.
    try {
        [void][Reflection.Assembly]::Load([IO.File]::ReadAllBytes($cecilPath))
    } catch {
        Write-Host ("兼容性检测组件 Mono.Cecil 无法在当前 PowerShell 运行时加载：" + $_.Exception.Message) -ForegroundColor Yellow
        return $false
    }

    $modules = @{}
    $failures = New-Object System.Collections.Generic.List[string]
    try {
        foreach ($check in $Checks) {
            $dll = [string]$check.dll
            $dllPath = Join-Path $managed $dll
            if (-not (Test-Path -LiteralPath $dllPath -PathType Leaf)) {
                $failures.Add("缺少关键游戏文件：$dll")
                continue
            }
            if (-not $modules.ContainsKey($dll)) {
                $modules[$dll] = [Mono.Cecil.ModuleDefinition]::ReadModule($dllPath)
            }
            $problem = Test-TypeCheck $modules[$dll] $check
            # Several checks share a type, so a missing type would otherwise be
            # reported once per check that mentions it.
            if ($null -ne $problem -and -not $failures.Contains("[$dll] $problem")) {
                $failures.Add("[$dll] $problem")
            }
        }
    } finally {
        foreach ($module in $modules.Values) { if ($null -ne $module) { $module.Dispose() } }
    }

    if ($failures.Count -gt 0) {
        $detail = ($failures | ForEach-Object { "  - $_" }) -join "`n"
        throw "游戏更新改变了汉化依赖的接口，为避免损坏游戏，本次未安装：`n$detail"
    }
    return $true
}

# Steam's own record of where it put things, so the patch folder does not have
# to sit inside the game directory for the installer to find it. Registry gives
# the main install; libraryfolders.vdf lists any extra drives the player added.
function Get-SteamLibraries {
    $libraries = @()
    foreach ($key in @("HKCU:\Software\Valve\Steam",
                       "HKLM:\SOFTWARE\WOW6432Node\Valve\Steam",
                       "HKLM:\SOFTWARE\Valve\Steam")) {
        try {
            $steamPath = (Get-ItemProperty -LiteralPath $key -ErrorAction Stop).SteamPath
        } catch { continue }
        if ([string]::IsNullOrWhiteSpace($steamPath)) { continue }
        $steamPath = $steamPath -replace '/', '\'
        if ($libraries -notcontains $steamPath) { $libraries += $steamPath }

        # "path"		"D:\\SteamLibrary" - one entry per extra library.
        $vdf = Join-Path $steamPath "steamapps\libraryfolders.vdf"
        if (-not (Test-Path -LiteralPath $vdf -PathType Leaf)) { continue }
        try { $text = Get-Content -LiteralPath $vdf -Raw -ErrorAction Stop } catch { continue }
        foreach ($m in [regex]::Matches($text, '"path"\s*"([^"]+)"')) {
            $lib = $m.Groups[1].Value -replace '\\\\', '\'
            if ($libraries -notcontains $lib) { $libraries += $lib }
        }
    }
    return $libraries
}

function Find-SteamGameRoot {
    foreach ($library in Get-SteamLibraries) {
        $common = Join-Path $library "steamapps\common"
        if (-not (Test-Path -LiteralPath $common -PathType Container)) { continue }

        $direct = Join-Path $common "Travelling at Night Demo"
        if (Test-Path -LiteralPath (Join-Path $direct "travelling.exe") -PathType Leaf) {
            return Get-FullPath $direct
        }
        # The folder gets renamed when the demo becomes the full game, so fall
        # back to whichever folder actually holds the executable.
        try { $folders = Get-ChildItem -LiteralPath $common -Directory -ErrorAction Stop } catch { continue }
        foreach ($folder in $folders) {
            if (Test-Path -LiteralPath (Join-Path $folder.FullName "travelling.exe") -PathType Leaf) {
                return Get-FullPath $folder.FullName
            }
        }
    }
    return $null
}

function Find-GameRoot([string]$Requested) {
    if (-not [string]::IsNullOrWhiteSpace($Requested)) {
        return Get-FullPath $Requested.Trim('"')
    }
    if (Test-Path -LiteralPath (Join-Path $PackageRoot "travelling.exe") -PathType Leaf) {
        return Get-FullPath $PackageRoot
    }
    $parent = Split-Path -Parent $PackageRoot
    if (Test-Path -LiteralPath (Join-Path $parent "travelling.exe") -PathType Leaf) {
        return Get-FullPath $parent
    }
    # Asked last, so a patch folder sitting in a game directory still wins -
    # that is the explicit choice, and it also covers non-Steam copies.
    $viaSteam = Find-SteamGameRoot
    if ($viaSteam) {
        Write-Host "已通过 Steam 自动定位到游戏目录。"
        return $viaSteam
    }
    throw "没有找到游戏目录。请把解压后的汉化包文件夹整个放进游戏目录，再运行。`n正确目录结尾：steamapps\common\Travelling at Night Demo"
}

Write-Host "$PackageName $PackageVersion" -ForegroundColor Green
Write-Host "构建时验证的游戏版本：$BuiltForGame"

Write-Stage "定位并校验游戏"
$GameRoot = Find-GameRoot $GameDir
$exePath = Join-Path $GameRoot "travelling.exe"
$versionPath = Join-Path $GameRoot "version.txt"
if (-not (Test-Path -LiteralPath $exePath -PathType Leaf)) { throw "目录中没有 travelling.exe：$GameRoot" }
if (Get-Process -Name "travelling" -ErrorAction SilentlyContinue) { throw "游戏正在运行。请完全退出游戏后重试。" }

$actualVersion = "(未知)"
if (Test-Path -LiteralPath $versionPath -PathType Leaf) {
    $actualVersion = (Get-Content -Raw -LiteralPath $versionPath).Trim()
}
if ($actualVersion -ne $BuiltForGame) {
    Write-Host "检测到未列名版本 $actualVersion；改为按关键接口判断兼容性。" -ForegroundColor Yellow
}
Write-Host "游戏目录：$GameRoot"
Write-Host "游戏版本：$actualVersion"

Write-Stage "校验安装包"
if (-not (Test-Path -LiteralPath $PayloadManifestPath -PathType Leaf)) { throw "安装包不完整：缺少 payload_manifest.json" }
if (-not (Test-Path -LiteralPath $PayloadRoot -PathType Container)) { throw "安装包不完整：缺少 payload 文件夹" }
$payloadManifest = [System.IO.File]::ReadAllText($PayloadManifestPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
if ([string](Get-Prop $payloadManifest "package_version") -ne $PackageVersion) {
    throw "安装脚本与安装清单版本不一致，安装包可能被混装或损坏。"
}
foreach ($entry in $payloadManifest.files) {
    $source = Resolve-SafeTarget $PayloadRoot ([string]$entry.path)
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "安装包缺少文件：$($entry.path)" }
    if ((Get-Sha256 $source) -ne ([string]$entry.sha256).ToUpperInvariant()) { throw "安装包文件校验失败：$($entry.path)" }
}
Write-Host "已校验 $(@($payloadManifest.files).Count) 个文件。"

$StateRoot = Join-Path $GameRoot $StateFolderName
$StateManifestPath = Join-Path $StateRoot "install_manifest.json"
$BackupRoot = Join-Path $StateRoot "backup"
$hadState = Test-Path -LiteralPath $StateManifestPath -PathType Leaf

# An update package carries the translation files, plugin, font and configs.
# Everything they need to load - BepInEx, XUnity - has to be here already. Checked
# before the compatibility stage, which reads Mono.Cecil out of the base
# install: without this, running an update package on a clean game fails there
# with "安装包缺少兼容性检测组件" instead of saying which download is wrong.
$isUpdate = [bool](Get-Prop $payloadManifest "update_only")
if ($isUpdate) {
    Write-Stage "检查更新包的前提"
    if (-not $hadState) {
        throw "这是更新包，需要先装过完整汉化包。请优先下载完整安装包。"
    }
    Write-Host "已安装版本：$([string](([System.IO.File]::ReadAllText($StateManifestPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json).package_version))。" -ForegroundColor Green
}

Write-Stage "检测游戏接口兼容性"
$compatChecked = Test-GameCompatibility $GameRoot (Get-Prop $payloadManifest "compatibility_checks")
if ($compatChecked -eq $false) {
    if ($actualVersion -ne $BuiltForGame) {
        throw "当前 PowerShell 无法加载兼容性检测组件，且游戏版本（$actualVersion）与补丁目标（$BuiltForGame）不符。为避免损坏游戏，本次未安装。请改用较新的 PowerShell（如 PowerShell 7）重试。"
    }
    Write-Host "兼容性检测组件不可用：已按版本号通过预检（接口级检查已跳过）。" -ForegroundColor Yellow
} else {
    Write-Host "关键接口兼容性检测：通过" -ForegroundColor Green
}

$oldState = $null
$oldByPath = @{}
if ($hadState) {
    $oldState = [System.IO.File]::ReadAllText($StateManifestPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
    foreach ($record in $oldState.files) { $oldByPath[[string]$record.path] = $record }
    Write-Host "检测到已安装版本：$($oldState.package_version)，将原地升级。" -ForegroundColor Yellow
} elseif (Test-Path -LiteralPath $StateRoot) {
    throw "检测到不完整的旧安装状态：$StateRoot。为保护备份，安装器不会自动覆盖。"
}

# No install record, yet the loader and BepInEx are there: a patch put in by
# hand, or by a package from before the installer existed (pre 2026-08-17),
# or another group's pack. The game ships none of these files itself. Left
# in place they would be recorded below as the player's "originals", backed
# up, and faithfully restored on uninstall - the old patch would outlive
# ours. Move the whole set aside instead, under the state folder, so this
# install starts from a clean game and the uninstaller ends at one. Only
# the known patch paths are touched, never anything else in the game dir.
$legacyRoot = $null
if (-not $hadState) {
    $legacyMarkers = @("BepInEx", "winhttp.dll", "doorstop_config.ini", ".doorstop_version")
    $legacyPresent = @($legacyMarkers | Where-Object { Test-Path -LiteralPath (Join-Path $GameRoot $_) })
    if ($legacyPresent.Count -gt 0) {
        Write-Stage "检测到旧版汉化残留"
        Write-Host "游戏目录里已有 BepInEx/载入器，但没有本安装器的安装记录：是旧版汉化包或手动放入的文件。" -ForegroundColor Yellow
        $legacyRoot = Join-Path $StateRoot ("legacy_" + (Get-Date -Format "yyyyMMdd_HHmmss"))
        New-Item -ItemType Directory -Path $legacyRoot -Force | Out-Null
        # Anything the old patch left next to the exe that we also ship; a
        # font bundle under our name from an earlier build counts too.
        $legacyPaths = @($legacyPresent) + @($payloadManifest.files | ForEach-Object { [string]$_.path } |
            Where-Object { $_ -notmatch "[\\/]" -and $legacyMarkers -notcontains $_ -and
                           (Test-Path -LiteralPath (Join-Path $GameRoot $_)) })
        foreach ($relative in ($legacyPaths | Sort-Object -Unique)) {
            $from = Resolve-SafeTarget $GameRoot $relative
            $to = Resolve-SafeTarget $legacyRoot $relative
            Move-Item -LiteralPath $from -Destination $to -Force
            Write-Host "已移走：$relative"
        }
        Write-Host "旧文件保存在 $legacyRoot，确认新版正常后可以删除。" -ForegroundColor Yellow
    }
}

$transactionId = [Guid]::NewGuid().ToString("N")
$TransactionBase = Join-Path ([System.IO.Path]::GetTempPath()) "travellingzh_transactions"
$TransactionRoot = Join-Path $TransactionBase ("transaction_" + $transactionId)
$TransactionBackup = Join-Path $TransactionRoot "before"
$OldManifestBackup = Join-Path $TransactionRoot "old_install_manifest.json"
$timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$PreservedUserRoot = Join-Path $StateRoot ("preserved_user_files\" + $timestamp)
$transactionRecords = New-Object System.Collections.Generic.List[object]
$newRecords = New-Object System.Collections.Generic.List[object]

Write-Stage $(if ($hadState) { "原地升级并保留回滚点" } else { "安装并建立备份" })
New-Item -ItemType Directory -Path $TransactionBackup -Force | Out-Null
New-Item -ItemType Directory -Path $BackupRoot -Force | Out-Null
if ($hadState) { Copy-Item -LiteralPath $StateManifestPath -Destination $OldManifestBackup -Force }

try {
    foreach ($entry in $payloadManifest.files) {
        $relative = [string]$entry.path
        $source = Resolve-SafeTarget $PayloadRoot $relative
        $target = Resolve-SafeTarget $GameRoot $relative
        $newHash = ([string]$entry.sha256).ToUpperInvariant()
        # Files the game or BepInEx rewrites at runtime. Their on-disk hash
        # drifts from what we shipped, which must not be mistaken for the
        # player having hand-edited them.
        $volatile = [bool](Get-Prop $entry "volatile")

        $targetParent = Split-Path -Parent $target
        if (-not (Test-Path -LiteralPath $targetParent)) { New-Item -ItemType Directory -Path $targetParent -Force | Out-Null }

        $existedBefore = Test-Path -LiteralPath $target -PathType Leaf
        if ($existedBefore) {
            $before = Resolve-SafeTarget $TransactionBackup $relative
            $beforeParent = Split-Path -Parent $before
            if (-not (Test-Path -LiteralPath $beforeParent)) { New-Item -ItemType Directory -Path $beforeParent -Force | Out-Null }
            Copy-Item -LiteralPath $target -Destination $before -Force
        }
        $transactionRecords.Add([pscustomobject]@{ path = $relative; existed = $existedBefore })

        $disposition = "created"
        $backupRelative = $null
        if ($oldByPath.ContainsKey($relative)) {
            # Upgrade: keep whatever the first install recorded about the
            # player's own copy, and never overwrite the original backup.
            $oldRecord = $oldByPath[$relative]
            $disposition = [string]$oldRecord.disposition
            $backupRelative = Get-Prop $oldRecord "backup_path"
            if ($existedBefore -and -not $volatile) {
                $currentHash = Get-Sha256 $target
                $oldHash = ([string]$oldRecord.sha256).ToUpperInvariant()
                if ($currentHash -ne $oldHash -and $currentHash -ne $newHash) {
                    $preserved = Resolve-SafeTarget $PreservedUserRoot $relative
                    $preservedParent = Split-Path -Parent $preserved
                    if (-not (Test-Path -LiteralPath $preservedParent)) { New-Item -ItemType Directory -Path $preservedParent -Force | Out-Null }
                    Copy-Item -LiteralPath $target -Destination $preserved -Force
                    Write-Host "已另存用户修改：$relative" -ForegroundColor Yellow
                }
            }
        } elseif ($existedBefore) {
            $currentHash = Get-Sha256 $target
            if ($currentHash -eq $newHash) {
                $disposition = "preexisting_identical"
            } else {
                $disposition = "replaced"
                $backupRelative = $relative
                $originalBackup = Resolve-SafeTarget $BackupRoot $relative
                $originalBackupParent = Split-Path -Parent $originalBackup
                if (-not (Test-Path -LiteralPath $originalBackupParent)) { New-Item -ItemType Directory -Path $originalBackupParent -Force | Out-Null }
                Copy-Item -LiteralPath $target -Destination $originalBackup -Force
            }
        }

        if (-not $existedBefore -or (Get-Sha256 $target) -ne $newHash) {
            Copy-Item -LiteralPath $source -Destination $target -Force
        }
        $newRecords.Add([pscustomobject]@{
            path = $relative
            sha256 = $newHash
            disposition = $disposition
            backup_path = $backupRelative
            volatile = $volatile
        })
    }

    if ($isUpdate -and $hadState) {
        # An update package ships only the translation files, but the state
        # manifest has to keep describing the whole install: it is what the
        # uninstaller walks, and what the stale-file sweep below compares
        # against. Without this carry-over the sweep read every file of the
        # base install as "no longer shipped" and removed it - BepInEx, the
        # loader, the font - right after a successful-looking update.
        $shipped = @{}
        foreach ($r in $newRecords) { $shipped[[string]$r.path] = $true }
        foreach ($record in $oldState.files) {
            if (-not $shipped.ContainsKey([string]$record.path)) { $newRecords.Add($record) }
        }
    }

    $state = [ordered]@{
        package = $PackageName
        package_version = $PackageVersion
        game_version = $actualVersion
        installed_at = if ($hadState -and (Get-Prop $oldState "installed_at")) { [string]$oldState.installed_at } else { (Get-Date).ToString("o") }
        updated_at = (Get-Date).ToString("o")
        game_root = $GameRoot
        files = $newRecords
    }
    $state | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $StateManifestPath -Encoding UTF8
} catch {
    Write-Host "安装失败，正在恢复安装前状态……" -ForegroundColor Red
    for ($i = $transactionRecords.Count - 1; $i -ge 0; $i--) {
        $record = $transactionRecords[$i]
        $target = Resolve-SafeTarget $GameRoot ([string]$record.path)
        if ($record.existed) {
            $before = Resolve-SafeTarget $TransactionBackup ([string]$record.path)
            if (Test-Path -LiteralPath $before -PathType Leaf) {
                $parent = Split-Path -Parent $target
                if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
                Copy-Item -LiteralPath $before -Destination $target -Force
            }
        } elseif (Test-Path -LiteralPath $target -PathType Leaf) {
            Remove-Item -LiteralPath $target -Force
        }
    }
    if ($hadState -and (Test-Path -LiteralPath $OldManifestBackup -PathType Leaf)) {
        Copy-Item -LiteralPath $OldManifestBackup -Destination $StateManifestPath -Force
    } elseif (-not $hadState -and (Test-Path -LiteralPath $StateRoot)) {
        # A legacy patch moved aside above goes back where it was: the
        # player had a working (old) patch before this attempt, and a
        # failed install must not leave them with none.
        if ($legacyRoot -and (Test-Path -LiteralPath $legacyRoot)) {
            foreach ($item in Get-ChildItem -LiteralPath $legacyRoot -Force) {
                Move-Item -LiteralPath $item.FullName -Destination (Join-Path $GameRoot $item.Name) -Force
            }
        }
        Remove-Item -LiteralPath $StateRoot -Recurse -Force
    }
    throw
}

if (Test-Path -LiteralPath $TransactionRoot) {
    $transactionBaseFull = (Get-FullPath $TransactionBase) + '\'
    $txFull = Get-FullPath $TransactionRoot
    if (-not $txFull.StartsWith($transactionBaseFull, [StringComparison]::OrdinalIgnoreCase)) { throw "事务目录安全检查失败。" }
    Remove-Item -LiteralPath $TransactionRoot -Recurse -Force
}

# Best-effort: a file this package shipped in a previous version but no longer
# ships (renamed or dropped) is not touched by the loop above, since that loop
# only walks the *current* manifest. Sweep it here so upgrades don't leave
# orphaned translation files behind. Never fails the install - the transaction
# above already committed successfully.
if ($hadState) {
    $newPaths = @{}
    foreach ($r in $newRecords) { $newPaths[[string]$r.path] = $true }
    $staleRelatives = @($oldByPath.Keys | Where-Object { -not $newPaths.ContainsKey($_) })
    if ($staleRelatives.Count -gt 0) {
        Write-Stage "清理已不再随本包分发的旧文件"
        foreach ($relative in $staleRelatives) {
            try {
                $oldRecord = $oldByPath[$relative]
                $target = Resolve-SafeTarget $GameRoot $relative
                if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { continue }
                $currentHash = Get-Sha256 $target
                $recordedHash = ([string]$oldRecord.sha256).ToUpperInvariant()
                if ($currentHash -ne $recordedHash) {
                    Write-Host "旧文件已被修改，保留不动：$relative" -ForegroundColor Yellow
                    continue
                }
                $disposition = [string]$oldRecord.disposition
                $backupRelative = Get-Prop $oldRecord "backup_path"
                if ($disposition -eq "replaced" -and -not [string]::IsNullOrEmpty($backupRelative)) {
                    $backupSource = Resolve-SafeTarget $BackupRoot $backupRelative
                    if (Test-Path -LiteralPath $backupSource -PathType Leaf) {
                        Copy-Item -LiteralPath $backupSource -Destination $target -Force
                        Write-Host "已恢复原文件：$relative" -ForegroundColor Yellow
                        continue
                    }
                }
                if ($disposition -eq "preexisting_identical") { continue }
                Remove-Item -LiteralPath $target -Force
                Write-Host "已移除旧版文件：$relative" -ForegroundColor Yellow
            } catch {
                Write-Host ("清理旧文件时出错，已跳过：$relative - " + $_.Exception.Message) -ForegroundColor Yellow
            }
        }
    }
}

Write-Stage "安装或升级完成"
Write-Host "当前汉化版本：$PackageVersion" -ForegroundColor Green
Write-Host "现在可以直接从 Steam 启动游戏。"
