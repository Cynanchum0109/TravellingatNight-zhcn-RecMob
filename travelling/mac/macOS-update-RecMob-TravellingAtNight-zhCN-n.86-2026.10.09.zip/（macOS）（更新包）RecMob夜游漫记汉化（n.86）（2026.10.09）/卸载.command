#!/bin/sh
# 夜游漫记 简体中文补丁 - macOS 卸载器
#
# 把安装器装进去的文件删掉，并把它备份的原文件放回原位。
# 游戏本体（travelling.app）从头到尾没被动过，所以卸载不需要碰它。

set -e

PackageName="夜游漫记 Demo 简体中文补丁"
StateFolderName=".travellingzh_patch"

a="/$0"; a=${a%/*}; a=${a#/}; a=${a:-.}
HERE=$(cd "$a" && pwd -P)
MANIFEST="$HERE/installer_files/payload_manifest.json"
[ -f "$MANIFEST" ] || MANIFEST="$HERE/payload_manifest.json"

say() { printf '\n== %s ==\n' "$1"; }
die() { printf '\n错误：%s\n\n' "$1" 1>&2; printf '按回车结束，然后直接关掉这个窗口。'; read -r _ </dev/tty 2>/dev/null || true; exit 1; }

printf '%s - 卸载\n' "$PackageName"

[ -f "$MANIFEST" ] || die "找不到 payload_manifest.json。请在解压出来的补丁文件夹里运行本脚本。"

say "查找游戏目录"

GAME=""
if [ -n "$1" ]; then
    GAME="$1"
elif [ -d "$HERE/travelling.app" ]; then
    GAME="$HERE"
else
    STEAM="$HOME/Library/Application Support/Steam"
    LIBS="$STEAM/steamapps"
    VDF="$STEAM/steamapps/libraryfolders.vdf"
    if [ -f "$VDF" ]; then
        EXTRA=$(sed -n 's/^[[:space:]]*"path"[[:space:]]*"\(.*\)"[[:space:]]*$/\1/p' "$VDF")
        LIBS="$LIBS
$(printf '%s\n' "$EXTRA" | sed 's|$|/steamapps|')"
    fi
    OLDIFS=$IFS; IFS='
'
    for lib in $LIBS; do
        [ -d "$lib/common" ] || continue
        for d in "$lib/common"/*; do
            if [ -d "$d/travelling.app" ]; then GAME="$d"; break; fi
        done
        [ -n "$GAME" ] && break
    done
    IFS=$OLDIFS
fi

[ -n "$GAME" ] || die "没找到游戏目录。把游戏目录拖到本脚本图标上再松手。"
GAME=$(cd "$GAME" && pwd -P)
printf '游戏目录：%s\n' "$GAME"

STATE="$GAME/$StateFolderName"
BACKUP="$STATE/backup"

PATHS=$(sed -n 's/^[[:space:]]*"path"[[:space:]]*:[[:space:]]*"\(.*\)",\{0,1\}[[:space:]]*$/\1/p' "$MANIFEST")
HASHES=$(sed -n 's/^[[:space:]]*"sha256"[[:space:]]*:[[:space:]]*"\(.*\)",\{0,1\}[[:space:]]*$/\1/p' "$MANIFEST")
NPATH=$(printf '%s\n' "$PATHS" | grep -c .)
[ "$NPATH" -gt 0 ] || die "清单里没有文件，无从卸载。"

# 2026-08-19 之前的安装器有个缺陷：升级时会把上一版补丁文件当成"游戏原件"
# 备份下来，于是卸载变成把补丁原样还原回去，一个文件都删不掉。那些坏备份
# 的内容与补丁自身逐字节相同，据此认出来并忽略，让装过旧版的人也能卸干净。
same_as_payload() {
    _want=$(printf '%s\n' "$HASHES" | sed -n "${2}p")
    [ -n "$_want" ] || return 1
    _got=$(shasum -a 256 "$1" | cut -d' ' -f1 | tr 'a-f' 'A-F')
    [ "$_got" = "$_want" ]
}

say "还原"

removed=0
restored=0
i=0
while [ $i -lt "$NPATH" ]; do
    i=$((i+1))
    rel=$(printf '%s\n' "$PATHS" | sed -n "${i}p")
    dst="$GAME/$rel"
    if [ -f "$BACKUP/$rel" ] && ! same_as_payload "$BACKUP/$rel" "$i"; then
        # 装补丁前这里本来就有文件（游戏自带的），放回去而不是删掉。
        mkdir -p "$(dirname "$dst")"
        cp -p "$BACKUP/$rel" "$dst"
        restored=$((restored+1))
    elif [ -f "$dst" ]; then
        rm -f "$dst"
        removed=$((removed+1))
    fi
done

# 补丁跑起来之后产生的日志，不在清单里，但确实是我们带来的，一并清掉。
# travelling_loader.log 是载入器写的；preloader_*.log 是 BepInEx 在
# preloader 阶段出错时写的，正常安装不会有。
rm -f "$GAME/travelling_loader.log"
rm -f "$GAME"/preloader_*.log

# 补丁自己建的空目录留着没意义，但只删空的，绝不递归删 —— 玩家可能往
# BepInEx/plugins 里放了别的 mod，那种目录非空，rmdir 会自己失败并跳过。
# -depth 保证从最深处往外删，否则父目录在子目录清空前轮到，删不掉。
find "$GAME/BepInEx" -type d -depth 2>/dev/null | while IFS= read -r d; do
    rmdir "$d" 2>/dev/null || true
done

printf '删除 %s 个，还原 %s 个。\n' "$removed" "$restored"

cat <<EOF

还要你手动做一件事：在 Steam 里右键《Travelling at Night》→ 属性 → 通用，
把「启动选项」清空。不清空的话 Steam 还会去调用已经被删掉的 run_bepinex.sh，
游戏起不来。

备份目录留着没删，确认游戏正常后可以自行删除：
  $BACKUP

EOF

# 说「关闭」会让人以为窗口会自己消失。终端默认「Shell 退出时不关闭窗口」，
# 按完回车会停在「[进程已完成]」，那是正常的，不是卡住。
printf '按回车结束，然后直接关掉这个窗口就行。'
read -r _ </dev/tty 2>/dev/null || true
