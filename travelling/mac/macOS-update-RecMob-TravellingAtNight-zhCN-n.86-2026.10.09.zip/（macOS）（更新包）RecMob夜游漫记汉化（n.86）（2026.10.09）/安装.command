#!/bin/sh
# 夜游漫记 简体中文补丁 - macOS 安装器
#
# 双击运行。它做四件事：
#   1. 找到游戏目录（Steam 库里带 travelling.app 的那个）
#   2. 按哈希校验补丁文件，没被改坏才继续
#   3. 备份会被覆盖的原文件，再把补丁装进去
#   4. 打印需要你手动粘进 Steam 的启动选项
#
# 为什么第 4 步不能自动：macOS 版 BepInEx 靠 DYLD_INSERT_LIBRARIES 注入，
# 必须由 Steam 通过启动选项调用 run_bepinex.sh 才能生效。启动选项存在
# Steam 自己的 localconfig.vdf 里，Steam 运行时改它会被原样覆盖回去，
# 所以只能你自己粘一次。
#
# 补丁装在 travelling.app 外面，不动 .app 内部。往签名过的 .app 里写文件
# 会破坏它的 bundle 签名，Apple Silicon 上可能直接拒绝启动。

set -e

# 这四行由 scripts/package_release.py 在打包时改写，保证脚本和它校验的
# 清单一定来自同一次构建。
PackageName="夜游漫记 Demo 简体中文补丁"
PackageVersion="v2026.10.09"
BuiltForGame="2026.9.n.86"
StateFolderName=".travellingzh_patch"
FontName="lxgwwenkai_6000"

# 脚本所在目录（双击运行时 $PWD 是家目录，不能用）
a="/$0"; a=${a%/*}; a=${a#/}; a=${a:-.}
HERE=$(cd "$a" && pwd -P)
# 包里这个脚本在顶层，负载在 installer_files/ 下面，好让玩家解压后直接
# 双击。散装摆放（两者同级）也认，方便在开发机上手工试跑。
PAYLOAD="$HERE/installer_files/payload"
MANIFEST="$HERE/installer_files/payload_manifest.json"
[ -d "$PAYLOAD" ] || PAYLOAD="$HERE/payload"
[ -f "$MANIFEST" ] || MANIFEST="$HERE/payload_manifest.json"

say() { printf '\n== %s ==\n' "$1"; }
die() { printf '\n错误：%s\n\n' "$1" 1>&2; printf '按回车结束，然后直接关掉这个窗口。'; read -r _ </dev/tty 2>/dev/null || true; exit 1; }

printf '%s %s（对应游戏版本 %s）\n' "$PackageName" "$PackageVersion" "$BuiltForGame"

[ -d "$PAYLOAD" ] || die "找不到 payload 目录。请把 zip 整个解压后再运行，不要只拖这一个文件出来。"
[ -f "$MANIFEST" ] || die "找不到 payload_manifest.json。同上，请重新完整解压。"

# ---------------------------------------------------------------- 找游戏目录

say "查找游戏目录"

GAME=""

if [ -n "$1" ]; then
    # 允许手动指定：把游戏目录拖到脚本上，或命令行传参
    GAME="$1"
elif [ -d "$HERE/travelling.app" ]; then
    # 玩家把整个补丁文件夹丢进了游戏目录
    GAME="$HERE"
else
    STEAM="$HOME/Library/Application Support/Steam"
    # libraryfolders.vdf 里每个 "path" 行是一个 Steam 库根目录。
    # 用 sed 抠出引号里的值，避开对 vdf 做完整解析。
    LIBS="$STEAM/steamapps"
    VDF="$STEAM/steamapps/libraryfolders.vdf"
    if [ -f "$VDF" ]; then
        EXTRA=$(sed -n 's/^[[:space:]]*"path"[[:space:]]*"\(.*\)"[[:space:]]*$/\1/p' "$VDF")
        LIBS="$LIBS
$(printf '%s\n' "$EXTRA" | sed 's|$|/steamapps|')"
    fi
    OLDIFS=$IFS; IFS='
'
    for lib in $LIBS; do
        [ -d "$lib/common" ] || continue
        for d in "$lib/common"/*; do
            if [ -d "$d/travelling.app" ]; then GAME="$d"; break; fi
        done
        [ -n "$GAME" ] && break
    done
    IFS=$OLDIFS
fi

[ -n "$GAME" ] || die "没有在 Steam 库里找到游戏。把游戏目录（含 travelling.app 的那个文件夹）拖到本脚本图标上再松手，或者把整个补丁文件夹放进游戏目录后重新双击。"
[ -d "$GAME/travelling.app" ] || die "「$GAME」里没有 travelling.app，不像是游戏目录。"

GAME=$(cd "$GAME" && pwd -P)
printf '游戏目录：%s\n' "$GAME"

# ------------------------------------------------------------------ 校验补丁

say "校验补丁文件"

# 清单是 package_release.py 写的 JSON。这里只需要 path 和 sha256 两个字段，
# 与其在 sh 里解析 JSON，不如按行抠 - 格式由我们自己生成，稳定可依赖。
#
# 尾逗号必须可有可无：带 "volatile": true 的条目（配置文件）把 sha256 顶到
# 中间去了，写死无逗号会漏掉它们，路径数和哈希数就对不上。
PATHS=$(sed -n 's/^[[:space:]]*"path"[[:space:]]*:[[:space:]]*"\(.*\)",\{0,1\}[[:space:]]*$/\1/p' "$MANIFEST")
HASHES=$(sed -n 's/^[[:space:]]*"sha256"[[:space:]]*:[[:space:]]*"\(.*\)",\{0,1\}[[:space:]]*$/\1/p' "$MANIFEST")

NPATH=$(printf '%s\n' "$PATHS" | grep -c .)
NHASH=$(printf '%s\n' "$HASHES" | grep -c .)
[ "$NPATH" -gt 0 ] || die "清单里一个文件都没有，补丁包不完整。"
[ "$NPATH" = "$NHASH" ] || die "清单自相矛盾（$NPATH 条路径对 $NHASH 条哈希），补丁包已损坏。"

i=0
BAD=0
while [ $i -lt "$NPATH" ]; do
    i=$((i+1))
    rel=$(printf '%s\n' "$PATHS"  | sed -n "${i}p")
    want=$(printf '%s\n' "$HASHES" | sed -n "${i}p")
    src="$PAYLOAD/$rel"
    if [ ! -f "$src" ]; then
        printf '缺失：%s\n' "$rel" 1>&2; BAD=$((BAD+1)); continue
    fi
    # 清单里的哈希是大写（package_release.py 的 sha256() 用 hexdigest().upper()，
    # 因为 Windows 的 Get-FileHash 就返回大写）。shasum 输出小写，直接比字符串
    # 会 54 个文件全部判为不符 —— 2026-08-18 首轮验收就栽在这里。
    got=$(shasum -a 256 "$src" | cut -d' ' -f1 | tr 'a-f' 'A-F')
    if [ "$got" != "$want" ]; then
        printf '哈希不符：%s\n' "$rel" 1>&2; BAD=$((BAD+1))
    fi
done
[ "$BAD" = 0 ] || die "$BAD 个文件校验失败。重新下载补丁包，不要用解压时报过错的那份。"
printf '%s 个文件全部通过。\n' "$NPATH"

# -------------------------------------------------------------- 更新包前提

# 更新包带译文、插件、字体和配置，装它的前提是完整包已经在了：BepInEx、
# XUnity 得是现成的。在动任何文件之前查完。
STATE="$GAME/$StateFolderName"
if grep -q '"update_only"[[:space:]]*:[[:space:]]*true' "$MANIFEST"; then
    say "检查更新包的前提"
    [ -f "$STATE/version.txt" ] || \
        die "这是更新包，需要先装过完整汉化包。请优先下载完整安装包。"
    printf '已安装 %s。\n' "$(cat "$STATE/version.txt")"
fi

# -------------------------------------------------------------------- 备份

BACKUP="$STATE/backup"

# 没有安装记录却已经有 BepInEx/载入器：手动放进去的、装安装器之前的老包、
# 或别家的汉化。游戏本身不带这些文件。留着不管，下面就会把它们当"游戏原件"
# 备份，卸载时再原样放回 —— 旧补丁比我们的活得还久。整套挪到状态目录下，
# 让这次安装从干净的游戏开始，卸载也在干净的游戏结束。只动已知的补丁路径。
if [ ! -f "$STATE/version.txt" ]; then
    legacy=""
    for m in BepInEx run_bepinex.sh libdoorstop.dylib .doorstop_version "$FontName"; do
        [ -e "$GAME/$m" ] && legacy="$legacy $m"
    done
    if [ -n "$legacy" ]; then
        say "检测到旧版汉化残留"
        printf '游戏目录里已有 BepInEx/载入器，但没有本安装器的安装记录：是旧版汉化包或手动放入的文件。\n'
        LEGACY="$STATE/legacy_$(date +%Y%m%d_%H%M%S)"
        mkdir -p "$LEGACY"
        for m in $legacy; do
            mv "$GAME/$m" "$LEGACY/$m"
            printf '已移走：%s\n' "$m"
        done
        printf '旧文件保存在 %s，确认新版正常后可以删除。\n' "$LEGACY"
    fi
fi

say "备份将被覆盖的原文件"

mkdir -p "$BACKUP"
saved=0

# 只有首次安装才需要备份：那时游戏目录里的同名文件才是游戏自带的。
# 升级时目录里躺的是上一版补丁，备份它们等于把"原件"记成我们自己的文件，
# 卸载时就会把补丁原样还原回去 —— 卸载彻底失效。
# Windows 的安装器靠 install_manifest.json 记录上一版装了什么来区分；
# 这里用状态目录里的 version.txt 当同样的标记。
if [ -f "$STATE/version.txt" ]; then
    printf '检测到已安装 %s，本次为升级：跳过备份。\n' "$(cat "$STATE/version.txt")"
    printf '（现在目录里的同名文件是上一版补丁，不是游戏原件。）\n'
else
    i=0
    while [ $i -lt "$NPATH" ]; do
        i=$((i+1))
        rel=$(printf '%s\n' "$PATHS" | sed -n "${i}p")
        dst="$GAME/$rel"
        if [ -f "$dst" ] && [ ! -f "$BACKUP/$rel" ]; then
            mkdir -p "$(dirname "$BACKUP/$rel")"
            cp -p "$dst" "$BACKUP/$rel"
            saved=$((saved+1))
        fi
    done
    printf '备份 %s 个文件到 %s\n' "$saved" "$BACKUP"
fi

# -------------------------------------------------------------------- 安装

say "安装"

i=0
while [ $i -lt "$NPATH" ]; do
    i=$((i+1))
    rel=$(printf '%s\n' "$PATHS" | sed -n "${i}p")
    dst="$GAME/$rel"
    mkdir -p "$(dirname "$dst")"
    cp "$PAYLOAD/$rel" "$dst"
done
printf '装入 %s 个文件。\n' "$NPATH"

chmod +x "$GAME/run_bepinex.sh"
# 更新器随负载装进游戏根目录；zip 是 Windows 上打的，可执行位到这里已经
# 丢了，不补上 Finder 会用文本编辑器打开它。更新包和完整包都带它。
[ -f "$GAME/检查汉化更新.command" ] && chmod +x "$GAME/检查汉化更新.command"

# 从网上下载的文件带 com.apple.quarantine 扩展属性，Gatekeeper 会拦住
# libdoorstop.dylib 的加载，症状是游戏正常启动但完全没有汉化。去掉隔离标记
# 只作用于我们刚装进去的这几个文件。
xattr -dr com.apple.quarantine "$GAME/run_bepinex.sh" "$GAME/libdoorstop.dylib" "$GAME/BepInEx" "$GAME/检查汉化更新.command" 2>/dev/null || true

# 中文字体由插件在运行时从 BepInEx/plugins/TravellingZh/fonts/ 里的 TTF 生成。
# 以前这里把 XUnity 的 FallbackFontTextMeshPro 改写成字体包的绝对路径；游戏换到
# Unity 6000.6 后加载任何 TMP 字体包都会直接崩溃，那一项必须保持留空，这里不再改。

printf '%s\n' "$PackageVersion" > "$STATE/version.txt"

# ------------------------------------------------------------- 收尾说明

say "还差最后一步：设置 Steam 启动选项"

# 这一行是整个安装里最容易出错的地方：路径含空格、要连引号、还长。
# 直接塞进剪贴板，玩家 Cmd+V 就行，不用手动去终端里选中复制。
#
# 为什么不干脆替玩家写进 Steam 配置：启动选项存在
# userdata/<id>/config/localconfig.vdf，而 Steam 退出时会用内存里的副本
# 覆盖该文件。玩家装补丁时 Steam 基本开着，改了也会被冲掉，却让玩家以为
# 已经设好 —— 那种失败的症状（游戏全英文）和根本没装一模一样，更难排查。
# 再加上多账号和手写 VDF 的风险，宁可让这一步显式地交给玩家。
LAUNCH_LINE="\"$GAME/run_bepinex.sh\" %command%"
if printf '%s' "$LAUNCH_LINE" | pbcopy 2>/dev/null; then
    COPIED="（已自动复制到剪贴板，直接 Command+V 即可）"
else
    COPIED="（请手动选中下面这一行复制）"
fi

cat <<EOF

在 Steam 里右键《Travelling at Night》→ 属性 → 通用 → 启动选项，
把下面这一整行粘进去（连引号一起）：
$COPIED

$LAUNCH_LINE

粘好后关掉属性窗口，正常点「开始游戏」即可。

⚠ 不设这一行，游戏能正常启动，但全是英文 —— 看起来就像补丁没装。
   之后如果发现没汉化，先回来确认这一行还在不在。

怎么确认装好了：启动一次游戏，然后看
  $GAME/BepInEx/LogOutput.log
里有没有 TravellingZh 的日志。有就是注入成功了。

卸载：运行同目录下的「卸载.command」，或手动删掉
  $GAME/BepInEx、run_bepinex.sh、libdoorstop.dylib、.doorstop_version
并清空 Steam 启动选项。原文件备份在 $BACKUP

EOF

# 说「关闭」会让人以为窗口会自己消失。终端默认「Shell 退出时不关闭窗口」，
# 按完回车会停在「[进程已完成]」，那是正常的，不是卡住。
printf '按回车结束，然后直接关掉这个窗口就行。'
read -r _ </dev/tty 2>/dev/null || true
